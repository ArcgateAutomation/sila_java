package com.silamoney.client.domain;

public class BusinessType extends Business {
}