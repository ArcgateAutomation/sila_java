package com.silamoney.client.domain;

public class BusinessRole extends Business {
}