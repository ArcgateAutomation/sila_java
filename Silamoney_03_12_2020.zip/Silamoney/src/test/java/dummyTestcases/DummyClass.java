package dummyTestcases;


import org.joda.time.LocalDate;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.silamoney.client.api.ApiResponse;
import com.silamoney.client.domain.BaseResponse;
import com.silamoney.client.domain.DocumentsResponse;
import com.silamoney.client.domain.GetDocumentMessage;
import com.silamoney.client.domain.GetWalletsResponse;
import com.silamoney.client.domain.SearchFilters;
import com.silamoney.client.domain.UploadDocumentMessage;
import com.silamoney.client.domain.User;
import com.silamoney.client.domain.Wallet;
import com.silamoney.client.security.EcdsaUtil;
import com.silamoney.common_files.Base_class;
import com.silamoney.common_files.Utility;
import io.qameta.allure.Description;

public class DummyClass extends Base_class{

	
	// Register Individual User
		@Test(priority = 1)
		@Description("Check registration with all valid data")
		public void Test_01_Test_01_register_with_all_valid_data() throws Exception {
//User Registration
		LocalDate birthdate = new LocalDate(2000, 01, 31);
		User user = new User(handle22,  firstName,  lastName, entityName,  streetAddress1, streetAddress2, city,  state, 
		postalCode,  phone,  email, identityNumber, Utility.getuser22CryptoAddress(), birthdate.toDate(), country);
		reader.setCellData(sheetName, privatekeys, 2, Utility.getuser22PrivateKey());
		System.out.println(Utility.getuser22PrivateKey());
		reader.setCellData(sheetName, cryptoAddress, 2, Utility.getuser22CryptoAddress());
		System.out.println(Utility.getuser22CryptoAddress());
		ApiResponse register_response =api.register(user);
		Thread.sleep(3000);
		System.out.println("Registartion Status: "+((BaseResponse) register_response.getData()).getMessage());
		
		
		
//Request KYC
		ApiResponse requestKycResponse = api.requestKYC(handle22, null, reader.getCellData(sheetName, privatekeys, 2));
		Thread.sleep(3000);
		System.out.println("Kyc Status: "+requestKycResponse.getStatusCode());
		System.out.println("Kyc Statuss message: "+((BaseResponse) requestKycResponse.getData()).getMessage());
		
		
		
		
//register wallet
	    Wallet wallet = api.generateWallet();
	    String walletVerificationSignature = EcdsaUtil.sign(wallet.getBlockChainAddress(), wallet.getPrivateKey());
		ApiResponse registerWalletResponse = api.registerWallet(handle22, wallet, walletVerificationSignature, reader.getCellData(sheetName, privatekeys, 2));

		System.out.println("registerWalletResponse: "+registerWalletResponse.getStatusCode()); // 200
		//Assert.assertEquals(registerWalletResponse.getStatusCode(), successStatusCode);
		//Assert.assertEquals(registerWalletResponse.getSuccess(), successTrue);
		//Assert.assertNotNull(((BaseResponse) registerWalletResponse.getData()).getReference());
		//Assert.assertEquals(((BaseResponse) registerWalletResponse.getData()).getStatus(), statusTrue);
		//Assert.assertEquals(((BaseResponse) registerWalletResponse.getData()).getMessage(), "Blockchain address 0x21cafefa25be9da6b61ffc282d024401639bdafe registered");
		
		
		
//Get Wallet
		
//		ApiResponse getWalletResponse = api.getWallet(handle22, reader.getCellData(sheetName, privatekeys, 2));
//
//		// Success Response Object
//		System.out.println(getWalletResponse.getStatusCode()); // 200
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getMessage());
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getReference());
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getSilaBalance());
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getStatus());
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getSuccess());
//		System.out.println(((com.silamoney.client.domain.GetWalletResponse) getWalletResponse.getData()).getWallet());
//		System.out.println(getWalletResponse.getData().getWallet()); // Wallet object
//		System.out.println(getWalletResponse.getData().getIsWhitelisted()); // Boolean
//		System.out.println(getWalletResponse.getData().getSilaBalance); // Sila balance
//		
//
//		Assert.assertEquals(getWalletResponse.getStatusCode(), 200);
//		
//		Assert.assertEquals(((GetWalletResponse)getWalletResponse.getData()).getStatus(),statusTrue);
//		Assert.assertTrue(((GetWalletResponse)getWalletResponse.getData()).getSuccess());
//		Assert.assertNotNull(((GetWalletResponse)getWalletResponse.getData()).getWallet().getNickname());
//		Assert.assertNotNull(((GetWalletResponse)getWalletResponse.getData()).getWallet().getBlockChainAddress());
//		Assert.assertNotNull(((GetWalletResponse)getWalletResponse.getData()).getWallet().getBlockChainNetwork());
//		Assert.assertEquals(((GetWalletResponse)getWalletResponse.getData()).getSilaBalance(), 0.0);

		
		
// Get Wallets
		SearchFilters filters = new SearchFilters();
		filters.setPage(1);//enter page 
		filters.setPerPage(20);//Enyer par page number
		filters.sortAscending(); //sorting 
		filters.setBlockChainNetwork(""); //network like ETH
		filters.setBlockChainAddress("");
		filters.setNickname(""); //send nick name

		ApiResponse response = api.getWallets("automationuser.silamoney.eth", filters, "55eaa88c07d028973319bf0ddf2278e5613183bbf0796c28d2a8b6bd0ab61f72");

		//  Success Response Object
		System.out.println(response.getStatusCode()); // 200
		System.out.println(((GetWalletsResponse)response.getData()).page);
		System.out.println(((GetWalletsResponse)response.getData()).returnedCount);
		System.out.println(((GetWalletsResponse)response.getData()).totalCount);
		System.out.println(((GetWalletsResponse)response.getData()).totalPageCount);
		System.out.println(((GetWalletsResponse)response.getData()).getWallets());
		System.out.println(((GetWalletsResponse)response.getData()).getWallets().getTotalCount);
		
		
/*
		
//UPload Document
		UploadDocumentMessage message1 = UploadDocumentMessage.builder()
		        .userHandle(handle22) // The user handle
		        .userPrivateKey(reader.getCellData(sheetName, privatekeys, 2)).filePath(workingDir+"/TestData/jpg_image.jpg").filename("dummy file") 
		        .mimeType("image/jpeg").documentType("tax_1040").identityType("other").name("Test jpg file") .description("upload jpg file") 
		        .build();
		ApiResponse uploadResponse = api.uploadDocument(message1);
		
		System.out.println(uploadResponse.getStatusCode()); // 200
		DocumentsResponse parsedResponse = (DocumentsResponse) uploadResponse.getData();
		String documentUuid=parsedResponse.getDocumentId();
		System.out.println(documentUuid);
*/
	
/*		
//List Documents
		List<String> docTypes = new ArrayList<String>();
		docTypes.add("tax_1040");
		// With no pagination
		ListDocumentsMessage message = ListDocumentsMessage.builder()
		        .userHandle(handle22)
		        .userPrivateKey(reader.getCellData(sheetName, privatekeys, 2)).search("Test jpg file")
		        .sortBy("name").docTypes(docTypes).startDate(LocalDate.now()).endDate(LocalDate.now().plusDays(1)).build();
		ApiResponse listResponse = api.listDocuments(message);
		// With pagination
		PaginationMessage pagination = PaginationMessage.builder().page(1).perPage(40).build();
		ApiResponse response = api.listDocuments(message, pagination);

		// Success Response
		System.out.println(response.getStatusCode()); // 200
	*/	
		
		
	/*	
		
//retrive document
		GetDocumentMessage message = GetDocumentMessage.builder()
		        .userHandle(handle22)
		        .userPrivateKey(reader.getCellData(sheetName, privatekeys, 2))
		        .documentId("3b6eb918-f3c3-4753-a7d4-7228efd55cfa")
		        .build();
		ApiResponse getDocResponse = api.getDocument(message);

		// Success response
		System.out.println(getDocResponse.getStatusCode()); // 200
		System.out.println(getDocResponse.getHeaders().get("Content-Type")); // Document MIME type
		System.out.println(getDocResponse.getHeaders().get("Content-Length")); // Document size in bytes
		System.out.println(getDocResponse.getHeaders().get("Content-Disposition")); // filename=<Document file name>
		System.out.println((String) getDocResponse.getData()); // The file binary data
		

		}
		
		*/
		

		}
	

}
